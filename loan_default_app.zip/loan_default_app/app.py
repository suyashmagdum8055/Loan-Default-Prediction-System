from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import psycopg2
import psycopg2.extras
import joblib
import pandas as pd
import numpy as np
from datetime import datetime
import hashlib
import os
from functools import wraps
import plotly
import plotly.graph_objs as go
import json
from datetime import timedelta
import traceback

app = Flask(__name__)
app.secret_key = 'loan-default-system-secret-key-2024'
app.permanent_session_lifetime = timedelta(hours=24)
CORS(app)

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'database': 'loan_default_system',
    'user': 'postgres',
    'password': 'your_password',  # CHANGE THIS
    'port': '5432'
}

def get_db_connection():
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        return None

# Load models
print("=" * 50)
print("Loading Models...")
print("=" * 50)

model = None
scaler = None
threshold = 0.5

try:
    model = joblib.load('models/xgboost_model.pkl')
    print(" XGBoost Model loaded successfully")
except Exception as e:
    print(f" Error loading model: {e}")

try:
    scaler = joblib.load('models/scaler.pkl')
    print(" Scaler loaded successfully")
except Exception as e:
    print(f" Error loading scaler: {e}")

try:
    threshold = joblib.load('models/optimal_threshold.pkl')
    print(f" Threshold loaded: {threshold}")
except Exception as e:
    print(f" Error loading threshold: {e}")

print("=" * 50)


# FEATURE COLUMNS (Complete list of 25 features)

feature_columns = [
    'Age', 'Income', 'LoanAmount', 'CreditScore', 'MonthsEmployed',
    'NumCreditLines', 'InterestRate', 'LoanTerm', 'DTIRatio',
    'HasMortgage', 'HasDependents', 'HasCoSigner',
    'Education_High School', "Education_Master's", 'Education_PhD',
    'EmploymentType_Part-time', 'EmploymentType_Self-employed',
    'EmploymentType_Unemployed', 'MaritalStatus_Married',
    'MaritalStatus_Single', 'LoanPurpose_Business',
    'LoanPurpose_Education', 'LoanPurpose_Home', 'LoanPurpose_Other',
    'RiskScore'
]


# COLUMNS THAT SCALER ACTUALLY KNOWS

scaler_columns = [
    'Age', 'Income', 'LoanAmount', 'CreditScore', 'MonthsEmployed',
    'NumCreditLines', 'InterestRate', 'DTIRatio', 'RiskScore'
]

# Login decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Update visitor count
def update_visitor_count():
    conn = get_db_connection()
    if conn:
        try:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM visitor_stats")
            count = cur.fetchone()[0]
            
            if count == 0:
                cur.execute("INSERT INTO visitor_stats (total_visitors, last_updated) VALUES (1, CURRENT_TIMESTAMP)")
            else:
                cur.execute("UPDATE visitor_stats SET total_visitors = total_visitors + 1, last_updated = CURRENT_TIMESTAMP")
            
            conn.commit()
            cur.close()
        except Exception as e:
            print(f"Error updating visitor count: {e}")
        finally:
            conn.close()

def get_visitor_count():
    conn = get_db_connection()
    if conn:
        try:
            cur = conn.cursor()
            cur.execute("SELECT total_visitors FROM visitor_stats")
            result = cur.fetchone()
            cur.close()
            return result[0] if result else 0
        except Exception as e:
            print(f"Error getting visitor count: {e}")
            return 0
        finally:
            conn.close()
    return 0


# PREPROCESSING FUNCTION

def preprocess_loan_data(loan_data):
    """Preprocess loan data to match model's expected features"""
    df = loan_data.copy()
    
    print("🔧 Starting preprocessing...")
    
    # Add LoanTerm (default to 36 months since not in form)
    if 'LoanTerm' not in df.columns:
        df['LoanTerm'] = 36
        print(" Added default LoanTerm = 36")
    
    # Encode binary columns (0/1)
    binary_cols = ['HasMortgage', 'HasDependents', 'HasCoSigner']
    for col in binary_cols:
        if col in df.columns:
            df[col] = df[col].map({'Yes': 1, 'No': 0})
    
    # Initialize all feature columns as 0
    for col in feature_columns:
        if col not in df.columns:
            df[col] = 0
    
    # One-hot encode Education
    if 'Education' in df.columns:
        edu_value = df['Education'].iloc[0]
        if edu_value == 'High School':
            df['Education_High School'] = 1
        elif edu_value == "Master's":
            df["Education_Master's"] = 1
        elif edu_value == 'Doctorate':
            df['Education_PhD'] = 1
    
    # One-hot encode Employment Type
    if 'EmploymentType' in df.columns:
        emp_value = df['EmploymentType'].iloc[0]
        if emp_value == 'Part-time':
            df['EmploymentType_Part-time'] = 1
        elif emp_value == 'Self-employed':
            df['EmploymentType_Self-employed'] = 1
        elif emp_value == 'Unemployed':
            df['EmploymentType_Unemployed'] = 1
    
    # One-hot encode Marital Status
    if 'MaritalStatus' in df.columns:
        mar_value = df['MaritalStatus'].iloc[0]
        if mar_value == 'Married':
            df['MaritalStatus_Married'] = 1
        elif mar_value == 'Single':
            df['MaritalStatus_Single'] = 1
    
    # One-hot encode Loan Purpose
    if 'LoanPurpose' in df.columns:
        purpose_value = df['LoanPurpose'].iloc[0]
        if purpose_value == 'Business':
            df['LoanPurpose_Business'] = 1
        elif purpose_value == 'Education':
            df['LoanPurpose_Education'] = 1
        elif purpose_value == 'Home':
            df['LoanPurpose_Home'] = 1
        elif purpose_value == 'Other':
            df['LoanPurpose_Other'] = 1
    
    # Calculate RiskScore
    df['RiskScore'] = (
        df['InterestRate'] * 0.13 +
        df['LoanAmount'] / 100000 * 0.09 -
        df['CreditScore'] / 100 * 0.03 -
        df['Age'] / 10 * 0.17
    )
    print(f" Calculated RiskScore: {df['RiskScore'].iloc[0]:.2f}")
    
    # Ensure all columns exist
    for col in feature_columns:
        if col not in df.columns:
            df[col] = 0
    
    # Select only the features the model expects
    df = df[feature_columns]
    
    # Save LoanTerm value BEFORE scaling
    loan_term_value = df['LoanTerm'].copy()
    print(f" Saved LoanTerm value: {loan_term_value.iloc[0]}")
    
    # Scale ONLY the numerical columns that the scaler knows
    try:
        print(f" Scaling {len(scaler_columns)} columns...")
        
        # Check if all scaler columns exist
        missing_cols = [col for col in scaler_columns if col not in df.columns]
        if missing_cols:
            print(f" Missing columns in df: {missing_cols}")
            for col in missing_cols:
                df[col] = 0
        
        # Perform scaling
        df[scaler_columns] = scaler.transform(df[scaler_columns])
        print(f" Scaling successful")
    except Exception as e:
        print(f" Scaling error: {e}")
        raise
    
    # Restore original LoanTerm value (not scaled)
    df['LoanTerm'] = loan_term_value
    print(f" Restored LoanTerm value: {df['LoanTerm'].iloc[0]}")
    
    print(" Preprocessing complete!")
    return df

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        if conn:
            try:
                cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
                cur.execute("SELECT * FROM users WHERE username = %s", (username,))
                user = cur.fetchone()
                cur.close()
                
                if user and check_password_hash(user['password_hash'], password):
                    session.permanent = True
                    session['user_id'] = user['user_id']
                    session['username'] = user['username']
                    
                    cur = conn.cursor()
                    cur.execute("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = %s", (user['user_id'],))
                    conn.commit()
                    cur.close()
                    conn.close()
                    
                    return redirect(url_for('home'))
                else:
                    conn.close()
                    return render_template('login.html', error='Invalid username or password')
            except Exception as e:
                conn.close()
                return render_template('login.html', error=f'Database error: {str(e)}')
        else:
            return render_template('login.html', error='Database connection failed')
    
    update_visitor_count()
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            return render_template('signup.html', error='Passwords do not match')
        
        if len(password) < 6:
            return render_template('signup.html', error='Password must be at least 6 characters')
        
        password_hash = generate_password_hash(password)
        
        conn = get_db_connection()
        if conn:
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
                    (username, email, password_hash)
                )
                conn.commit()
                cur.close()
                conn.close()
                return redirect(url_for('login'))
            except psycopg2.IntegrityError:
                conn.close()
                return render_template('signup.html', error='Username or email already exists')
            except Exception as e:
                conn.close()
                return render_template('signup.html', error=f'Error: {str(e)}')
        else:
            return render_template('signup.html', error='Database connection failed')
    
    return render_template('signup.html')

@app.route('/home')
@login_required
def home():
    return render_template('home.html', username=session.get('username'))

@app.route('/predict', methods=['GET', 'POST'])
@login_required
def predict():
    if request.method == 'POST':
        try:
           
            print("Starting prediction...")
            
            # Get form data
            loan_data = pd.DataFrame({
                'Age': [int(request.form['age'])],
                'Income': [int(request.form['income'])],
                'LoanAmount': [int(request.form['loan_amount'])],
                'CreditScore': [int(request.form['credit_score'])],
                'MonthsEmployed': [int(request.form['months_employed'])],
                'NumCreditLines': [int(request.form['num_credit_lines'])],
                'InterestRate': [float(request.form['interest_rate'])],
                'DTIRatio': [float(request.form['dti_ratio'])],
                'Education': [request.form['education']],
                'EmploymentType': [request.form['employment_type']],
                'MaritalStatus': [request.form['marital_status']],
                'HasMortgage': [request.form['has_mortgage']],
                'HasDependents': [request.form['has_dependents']],
                'LoanPurpose': [request.form['loan_purpose']],
                'HasCoSigner': [request.form['has_cosigner']]
            })
            
            print(f" Input data received: {loan_data.shape[1]} fields")
            
            # Check if models are loaded
            if model is None:
                return render_template('predict.html', 
                                     error="Model not loaded. Please ensure xgboost_model.pkl exists",
                                     result=False)
            
            if scaler is None:
                return render_template('predict.html', 
                                     error="Scaler not loaded. Please ensure scaler.pkl exists",
                                     result=False)
            
            # Preprocess and predict
            processed_data = preprocess_loan_data(loan_data)
            print(f" Processed data shape: {processed_data.shape}")
            
            # Make prediction
            probability = model.predict_proba(processed_data)[0, 1]
            print(f" Prediction probability: {probability:.4f}")
            print(f"⚖️ Decision threshold: {threshold:.4f}")
            
            prediction = "REJECT" if probability >= threshold else "APPROVE"
            
            if probability >= 0.6:
                risk_level = "High"
                risk_color = "danger"
            elif probability >= 0.3:
                risk_level = "Medium"
                risk_color = "warning"
            else:
                risk_level = "Low"
                risk_color = "success"
            
            # Save to database
            conn = get_db_connection()
            if conn:
                try:
                    cur = conn.cursor()
                    cur.execute("""
                        INSERT INTO predictions (
                            user_id, age, income, loan_amount, credit_score, months_employed,
                            num_credit_lines, interest_rate, dti_ratio, education, employment_type,
                            marital_status, has_mortgage, has_dependents, loan_purpose, has_cosigner,
                            default_probability, prediction_result, risk_level
                        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        session['user_id'], int(request.form['age']), int(request.form['income']),
                        int(request.form['loan_amount']), int(request.form['credit_score']),
                        int(request.form['months_employed']), int(request.form['num_credit_lines']),
                        float(request.form['interest_rate']), float(request.form['dti_ratio']),
                        request.form['education'], request.form['employment_type'],
                        request.form['marital_status'], request.form['has_mortgage'],
                        request.form['has_dependents'], request.form['loan_purpose'],
                        request.form['has_cosigner'], float(probability), prediction, risk_level
                    ))
                    conn.commit()
                    cur.close()
                    print(" Prediction saved to database")
                except Exception as e:
                    print(f" Database save error: {e}")
                finally:
                    conn.close()
            
            print(f" Final Prediction: {prediction}")
           
            
            return render_template('predict.html', 
                                 prediction=prediction,
                                 probability=probability * 100,
                                 risk_level=risk_level,
                                 risk_color=risk_color,
                                 result=True)
        except Exception as e:
            print(f" Prediction error: {e}")
            traceback.print_exc()
            return render_template('predict.html', 
                                 error=f"Prediction error: {str(e)}",
                                 result=False)
    
    return render_template('predict.html', result=False)

@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    if not conn:
        return render_template('dashboard.html', error="Database connection failed")
    
    try:
        cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        
        cur.execute("""
            SELECT 
                COUNT(*) as total_predictions,
                COALESCE(SUM(CASE WHEN prediction_result = 'APPROVE' THEN 1 ELSE 0 END), 0) as approvals,
                COALESCE(SUM(CASE WHEN prediction_result = 'REJECT' THEN 1 ELSE 0 END), 0) as rejections,
                COALESCE(AVG(default_probability), 0) as avg_probability
            FROM predictions WHERE user_id = %s
        """, (session['user_id'],))
        stats = cur.fetchone()
        
        if not stats or stats['total_predictions'] == 0:
            stats = {
                'total_predictions': 0,
                'approvals': 0,
                'rejections': 0,
                'avg_probability': 0
            }
        
        cur.execute("""
            SELECT * FROM predictions 
            WHERE user_id = %s 
            ORDER BY prediction_date DESC LIMIT 10
        """, (session['user_id'],))
        recent_predictions = cur.fetchall()
        
        visitor_count = get_visitor_count()
        
        cur.execute("""
            SELECT default_probability, age, income, loan_amount, credit_score, risk_level
            FROM predictions WHERE user_id = %s
            ORDER BY prediction_date DESC LIMIT 50
        """, (session['user_id'],))
        chart_data = cur.fetchall()
        
        cur.close()
        conn.close()
        
        graph_2d = None
        graph_3d = None
        
        # Convert chart_data to proper numeric types for Plotly
        if chart_data and len(chart_data) > 0:
            try:
                # Convert to list of dictionaries with proper numeric types
                chart_list = []
                for row in chart_data:
                    chart_list.append({
                        'age': float(row['age']) if row['age'] else 0,
                        'credit_score': float(row['credit_score']) if row['credit_score'] else 0,
                        'default_probability': float(row['default_probability']) if row['default_probability'] else 0,
                        'income': float(row['income']) if row['income'] else 0,
                        'loan_amount': float(row['loan_amount']) if row['loan_amount'] else 0,
                        'risk_level': str(row['risk_level']) if row['risk_level'] else 'Medium'
                    })
                
                df_chart = pd.DataFrame(chart_list)
                print(f" Chart data loaded: {len(df_chart)} rows")
                
                # Create 2D Plot with LIGHT THEME
                scatter_2d = go.Figure()
                
                # Define colors for risk levels
                risk_colors = {
                    'Low': '#28a745',
                    'Medium': '#ffc107',
                    'High': '#dc3545'
                }
                
                for risk in ['Low', 'Medium', 'High']:
                    mask = df_chart['risk_level'] == risk
                    if mask.any():
                        scatter_2d.add_trace(go.Scatter(
                            x=df_chart.loc[mask, 'age'].tolist(),
                            y=df_chart.loc[mask, 'default_probability'].tolist(),
                            mode='markers',
                            name=f'{risk} Risk',
                            marker=dict(
                                size=12,
                                opacity=0.7,
                                color=risk_colors.get(risk, '#667eea'),
                                line=dict(width=1, color='white')
                            ),
                            text=df_chart.loc[mask, 'income'].tolist(),
                            hovertemplate='<b>Age:</b> %{x}<br>' +
                                        '<b>Probability:</b> %{y:.1%}<br>' +
                                        '<b>Income:</b> $%{text:,.0f}<br>' +
                                        '<b>Risk:</b> ' + risk + '<extra></extra>'
                        ))
                
                scatter_2d.update_layout(
                    title=dict(
                        text='<b>Risk Analysis by Age</b>',
                        font=dict(color='#333333', size=16),
                        x=0.5
                    ),
                    xaxis=dict(
                        title=dict(text='<b>Age (Years)</b>', font=dict(color='#333333', size=12)),
                        tickfont=dict(color='#555555', size=11),
                        gridcolor='#e0e0e0',
                        linecolor='#cccccc',
                        linewidth=1,
                        showgrid=True,
                        zeroline=False
                    ),
                    yaxis=dict(
                        title=dict(text='<b>Default Probability</b>', font=dict(color='#333333', size=12)),
                        tickfont=dict(color='#555555', size=11),
                        gridcolor='#e0e0e0',
                        linecolor='#cccccc',
                        linewidth=1,
                        tickformat='.0%',
                        showgrid=True,
                        zeroline=False
                    ),
                    template='plotly_white',
                    height=450,
                    paper_bgcolor='white',
                    plot_bgcolor='#f8f9fa',
                    font=dict(color='#333333'),
                    showlegend=True,
                    legend=dict(
                        title=dict(text='<b>Risk Level</b>', font=dict(color='#333333', size=11)),
                        bgcolor='rgba(255,255,255,0.95)',
                        bordercolor='#dddddd',
                        borderwidth=1,
                        font=dict(color='#333333', size=11),
                        x=0.02,
                        y=0.98,
                        xanchor='left',
                        yanchor='top'
                    ),
                    hoverlabel=dict(
                        bgcolor='white',
                        font_size=11,
                        font_family='Segoe UI'
                    )
                )
                graph_2d = json.dumps(scatter_2d, cls=plotly.utils.PlotlyJSONEncoder)
                print(" 2D plot created successfully")
                
            except Exception as e:
                print(f"Error creating 2D plot: {e}")
                traceback.print_exc()
        
        # Create 3D Plot (requires at least 3 points)
        if chart_data and len(chart_data) >= 3:
            try:
                # Ensure we have a fresh DataFrame for 3D
                if 'df_chart' not in locals():
                    chart_list_3d = []
                    for row in chart_data:
                        chart_list_3d.append({
                            'age': float(row['age']) if row['age'] else 0,
                            'credit_score': float(row['credit_score']) if row['credit_score'] else 0,
                            'default_probability': float(row['default_probability']) if row['default_probability'] else 0,
                            'income': float(row['income']) if row['income'] else 0,
                        })
                    df_chart_3d = pd.DataFrame(chart_list_3d)
                else:
                    df_chart_3d = df_chart[['age', 'credit_score', 'default_probability', 'income']].copy()
                
                scatter_3d = go.Figure(data=[go.Scatter3d(
                    x=df_chart_3d['age'].tolist(),
                    y=df_chart_3d['credit_score'].tolist(),
                    z=df_chart_3d['default_probability'].tolist(),
                    mode='markers',
                    marker=dict(
                        size=6,
                        color=df_chart_3d['default_probability'].tolist(),
                        colorscale='Viridis',
                        showscale=True,
                        colorbar=dict(
                            title="Default Probability",
                            tickformat='.0%',
                            title_font=dict(color='#333333'),
                            tickfont=dict(color='#555555')
                        )
                    ),
                    text=df_chart_3d['income'].tolist(),
                    hovertemplate='<b>Age:</b> %{x}<br>' +
                                '<b>Credit Score:</b> %{y}<br>' +
                                '<b>Probability:</b> %{z:.1%}<br>' +
                                '<b>Income:</b> $%{text:,.0f}<extra></extra>'
                )])
                
                scatter_3d.update_layout(
                    title=dict(
                        text='<b>3D Risk Visualization</b>',
                        font=dict(color='#333333', size=16),
                        x=0.5
                    ),
                    scene=dict(
                        xaxis=dict(
                            title=dict(text='<b>Age (Years)</b>', font=dict(color='#333333', size=11)),
                            tickfont=dict(color='#555555', size=10),
                            backgroundcolor='#f8f9fa',
                            gridcolor='#e0e0e0',
                            showbackground=True
                        ),
                        yaxis=dict(
                            title=dict(text='<b>Credit Score</b>', font=dict(color='#333333', size=11)),
                            tickfont=dict(color='#555555', size=10),
                            backgroundcolor='#f8f9fa',
                            gridcolor='#e0e0e0',
                            showbackground=True
                        ),
                        zaxis=dict(
                            title=dict(text='<b>Default Probability</b>', font=dict(color='#333333', size=11)),
                            tickfont=dict(color='#555555', size=10),
                            tickformat='.0%',
                            backgroundcolor='#f8f9fa',
                            gridcolor='#e0e0e0',
                            showbackground=True
                        ),
                        bgcolor='white',
                        camera=dict(
                            eye=dict(x=1.5, y=1.5, z=1.5)
                        )
                    ),
                    template='plotly_white',
                    height=550,
                    paper_bgcolor='white',
                    margin=dict(l=0, r=0, t=50, b=0),
                    font=dict(color='#333333'),
                    hoverlabel=dict(
                        bgcolor='white',
                        font_size=11,
                        font_family='Segoe UI'
                    )
                )
                graph_3d = json.dumps(scatter_3d, cls=plotly.utils.PlotlyJSONEncoder)
                print("3D plot created successfully")
                
            except Exception as e:
                print(f"Error creating 3D plot: {e}")
                traceback.print_exc()
        else:
            print(f" Not enough data for 3D plot: {len(chart_data) if chart_data else 0} rows (need 3)")
        
        return render_template('dashboard.html', 
                             stats=stats,
                             recent_predictions=recent_predictions,
                             total_visitors=visitor_count,
                             username=session.get('username'),
                             graph_2d=graph_2d,
                             graph_3d=graph_3d)
    except Exception as e:
        print(f"Dashboard error: {e}")
        traceback.print_exc()
        return render_template('dashboard.html', error=str(e))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/api/predict', methods=['POST'])
@login_required
def api_predict():
    try:
        data = request.json
        loan_data = pd.DataFrame([data])
        processed_data = preprocess_loan_data(loan_data)
        probability = model.predict_proba(processed_data)[0, 1]
        prediction = "REJECT" if probability >= threshold else "APPROVE"
        
        return jsonify({
            'success': True,
            'probability': float(probability),
            'prediction': prediction,
            'threshold': float(threshold)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    print("\n" + "=" * 50)
    print("Starting Loan Default Prediction System")

    print(f"Model loaded: {model is not None}")
    print(f"Scaler loaded: {scaler is not None}")
    print(f"Threshold: {threshold}")
    print(f"Expected features: {len(feature_columns)}")
    print(f"Scaler columns: {scaler_columns}")

    print("\n Server running at: http://localhost:5000")
    print("\n")
    app.run(debug=True, host='0.0.0.0', port=5000)