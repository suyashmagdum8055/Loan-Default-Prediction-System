-- Create database
CREATE DATABASE loan_default_system;

\c loan_default_system;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- Prediction history table
CREATE TABLE IF NOT EXISTS predictions (
    prediction_id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(user_id),
    age INTEGER,
    income INTEGER,
    loan_amount INTEGER,
    credit_score INTEGER,
    months_employed INTEGER,
    num_credit_lines INTEGER,
    interest_rate FLOAT,
    dti_ratio FLOAT,
    education VARCHAR(50),
    employment_type VARCHAR(50),
    marital_status VARCHAR(50),
    has_mortgage VARCHAR(3),
    has_dependents VARCHAR(3),
    loan_purpose VARCHAR(100),
    has_cosigner VARCHAR(3),
    default_probability FLOAT,
    prediction_result VARCHAR(10),
    risk_level VARCHAR(10),
    prediction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Visitor counter table
CREATE TABLE IF NOT EXISTS visitor_stats (
    stat_id SERIAL PRIMARY KEY,
    total_visitors INTEGER DEFAULT 0,
    unique_visitors INTEGER DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_predictions_user_id ON predictions(user_id);
CREATE INDEX idx_predictions_date ON predictions(prediction_date);
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);

-- Insert initial visitor count
INSERT INTO visitor_stats (total_visitors, unique_visitors) VALUES (0, 0) 
ON CONFLICT DO NOTHING;

-- Create function to update visitor stats
CREATE OR REPLACE FUNCTION update_visitor_stats()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE visitor_stats 
    SET total_visitors = total_visitors + 1,
        last_updated = CURRENT_TIMESTAMP;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;